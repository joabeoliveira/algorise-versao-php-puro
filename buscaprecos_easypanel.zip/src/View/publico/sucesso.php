<div class="alert alert-success text-center">
    <h4 class="alert-heading">Obrigado!</h4>
    <p class="mb-0">Sua cotação foi recebida com sucesso.</p>
</div>